<?php
session_start();
if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
	foreach($_SESSION['ERRMSG_ARR'] as $msg) {
		echo '<span style="color:red;">',$msg,'</span>'; 
	}
	unset($_SESSION['ERRMSG_ARR']);
}
?>
<p><h1>Write to file</h1></p>
<form action="save.php" method="POST">
<!-- <span style="display: inline-block; width: 150px;">Input</span><input type="textarea" cols="40" rows="5" name="name" required="required" /><br> -->

<span style="display: inline-block; width: 150px;">Input</span><textarea class="textAreaMultiline" 
          placeholder="Hello, \nThis is multiline example \n\nHave Fun"
          name="name" rows="5" cols="35"></textarea>


<span style="display: inline-block; width: 150px;">&nbsp;</span><input type="submit" value="Save" />
</form>
