<?php
session_start();
$errmsg_arr = array();
$errflag = false;
$name 	= trim($_REQUEST["name"]);
$filename	= "informationlist.txt";
$MyFile 	= fopen($filename, "a");
$newline=$name."\r\n";		
fwrite($MyFile, $newline);
fclose($MyFile);
$errmsg_arr[] = ' data has been save to '.$filename.' file';
$errflag = true;
if($errflag) {
	$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
	session_write_close();
	header("location: index.php");
	exit();
}
die;
?>
